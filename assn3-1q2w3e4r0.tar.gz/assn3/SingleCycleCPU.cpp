#include "SingleCycleCPU.hpp"

/*****************************************************************/
/* SingleCycleCPU::advanceCycle                                  */
/*   - Execute a single MIPS instruction in a single clock cycle */
/*****************************************************************/
void SingleCycleCPU::advanceCycle() {
  /* DO NOT CHANGE THE FOLLOWING LINE */
  CPU::advanceCycle();

  /*****************************/
  /*********** FIXME ***********/
  /*****************************/
}

