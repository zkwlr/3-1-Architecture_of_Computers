#include "Memory.hpp"

void Memory::access(
  const std::bitset<32> *address, const std::bitset<32> *writeData,
  const std::bitset<1> *memRead, const std::bitset<1> *memWrite,
  std::bitset<32> *readData
) {
  assert(memRead != nullptr);
  assert(memWrite != nullptr);
  if (memRead->all() && memWrite->all()) {
    printf("ERROR: Both `memRead' and `memWrite' are set.\n");
    assert(!(memRead->all() && memWrite->all()));
  } else if (memRead->all()) {
    assert(address != nullptr);
    assert(readData != nullptr);

    /*************************************************/
    /********************* FIXME *********************/
    /*************************************************/
  } else if (memWrite->all()) { 
    assert(address != nullptr);
    assert(writeData != nullptr);

    /*************************************************/
    /********************* FIXME *********************/
    /*************************************************/
  }
}

