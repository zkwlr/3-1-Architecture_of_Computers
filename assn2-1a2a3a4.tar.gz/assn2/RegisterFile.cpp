#include "RegisterFile.hpp"

void RegisterFile::access(
  const std::bitset<5> *readRegister1, const std::bitset<5> *readRegister2,
  const std::bitset<5> *writeRegister, const std::bitset<32> *writeData,
  const std::bitset<1> *regWrite,
  std::bitset<32> *readData1, std::bitset<32> *readData2
) {
  if (regWrite->all()) {
    assert(writeRegister != nullptr && writeData != nullptr);

    /*************************************************/
    /********************* FIXME *********************/
    /*************************************************/
  } else {
    assert(readData1 != nullptr && readRegister1 != nullptr
           && readData2 != nullptr && readRegister2 != nullptr);

    /*************************************************/
    /********************* FIXME *********************/
    /*************************************************/
  }
}

