#include "SingleCycleCPU.hpp"

/******************************************************/
/* SingleCycleCPU::AND                                */
/*   - Perform logical AND on two BitWidth-bit values */
/*   - output = input0 & input1;                      */
/******************************************************/
template<size_t BitWidth>
void SingleCycleCPU::AND(
  const std::bitset<BitWidth> *input0, const std::bitset<BitWidth> *input1,
  std::bitset<BitWidth> *output
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/********************************************/
/* SingleCycleCPU::Add                      */
/*   - Add two BitWidth-bit signed integers */
/*   - output = input0 + input1;            */
/********************************************/
template<size_t BitWidth>
void SingleCycleCPU::Add(
  const std::bitset<BitWidth> *input0, const std::bitset<BitWidth> *input1,
  std::bitset<BitWidth> *output
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/***********************************************************************/
/* SingleCycleCPU::Mux                                                 */
/*   - Select one of the two BitWidth-bit inputs as the output         */
/*   - if (select == 0) { output = input0; } else { output = input1; } */
/***********************************************************************/
template<size_t BitWidth>
void SingleCycleCPU::Mux(
  const std::bitset<BitWidth> *input0, const std::bitset<BitWidth> *input1,
  const std::bitset<1> *select,
  std::bitset<BitWidth> *output
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/***************************************************************************/
/* SingleCycleCPU::SignExtend                                              */
/*   - Expand an InputBitWidth-bit signed integer to an OutputBitWidth-bit */
/*     signed integer                                                      */
/*   - output = input;                                                     */
/***************************************************************************/
template<size_t InputBitWidth, size_t OutputBitWidth>
void SingleCycleCPU::SignExtend(
  const std::bitset<InputBitWidth> *input,
  std::bitset<OutputBitWidth> *output
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/*******************************************************************/
/* SingleCycleCPU::ShiftLeft2                                      */
/*   - Shift the BitWidth-bit signed integer to the left by 2 bits */
/*   - output = (input << 2);                                      */
/*******************************************************************/
template<size_t BitWidth>
void SingleCycleCPU::ShiftLeft2(
  const std::bitset<BitWidth> *input,
  std::bitset<BitWidth> *output
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/*****************************************************************/
/* SingleCycleCPU::ALU                                           */
/*   - Perform an arithmetic/logical operation on the two inputs */
/*   - Refer to the slides and textbook for the exact operation  */
/*****************************************************************/
void SingleCycleCPU::ALU(
  const std::bitset<32> *input0, const std::bitset<32> *input1,
  const std::bitset<4> *control,
  std::bitset<32> *output, std::bitset<1> *zero
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/*****************************************************************************************/
/* SingleCycleCPU::Control                                                               */
/*   - Produce appropriate control signals for the datapath w.r.t. the provided `opcode' */
/*****************************************************************************************/
void SingleCycleCPU::Control(
  const std::bitset<6> *opcode,
  std::bitset<1> *regDst, std::bitset<1> *branch, std::bitset<1> *memRead,
  std::bitset<1> *memToReg, std::bitset<2> *aluOp, std::bitset<1> *memWrite,
  std::bitset<1> *aluSrc, std::bitset<1> *regWrite
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/***********************************************************************************************/
/* SingleCycleCPU::ALUControl                                                                  */
/*   - Produce the appropriate control signal for the ALU w.r.t. the given `ALUOp' and `funct' */
/***********************************************************************************************/
void SingleCycleCPU::ALUControl(
  const std::bitset<2> *aluOp, const std::bitset<6> *funct,
  std::bitset<4> *aluControl
) {
  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

/*****************************************************************/
/* SingleCycleCPU::AdvanceCycle                                  */
/*   - Execute a single MIPS instruction in a single clock cycle */
/*****************************************************************/
void SingleCycleCPU::advanceCycle() {
  /* DO NOT CHANGE THE FOLLOWING TWO LINES */
  m_currCycle++;
  printf("INFO: Cycle %llu: Executing the instruction located at 0x%08lx\n", m_currCycle, m_PC.to_ulong());

  /*************************************************/
  /********************* FIXME *********************/
  /*************************************************/
}

